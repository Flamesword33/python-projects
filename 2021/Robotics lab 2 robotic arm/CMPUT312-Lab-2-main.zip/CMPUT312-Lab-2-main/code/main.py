#!/usr/bin/env python3
# Base code from https://github.com/ev3dev/vscode-hello-python

"""Lab 2"""

import os
import sys
import math
import time
from ev3dev2.motor import (
    MediumMotor,
    OUTPUT_A,
    OUTPUT_B,
    MoveTank,
    SpeedPercent,
    # MoveDifferential,
)
from ev3dev2.sensor.lego import TouchSensor

from ev3dev2.sound import Sound

# OUTPUT_A controls main axis of the robot
# OUTPUT_B controls the secondary axis of the robot
arm = MoveTank(OUTPUT_A, OUTPUT_B, motor_class=MediumMotor)

# In millimeters
DISTANCE_BETWEEN_STUD = 8
FIRST_ARM_LENGTH = DISTANCE_BETWEEN_STUD*12
SECOND_ARM_LENGTH = DISTANCE_BETWEEN_STUD*12
MOTOR_TO_AXIS_DEGREE = 395/90
MAX_LENGTH = FIRST_ARM_LENGTH+SECOND_ARM_LENGTH


def debug_print(*args, **kwargs):
    """Print debug messages to stderr.

    This shows up in the output panel in VS Code.
    """
    print(*args, **kwargs, file=sys.stderr)


def reset_console():
    """Resets the console to the default state"""
    print("\x1Bc", end="")


def set_cursor(state):
    """Turn the cursor on or off"""
    if state:
        print("\x1B[?25h", end="")
    else:
        print("\x1B[?25l", end="")


def set_font(name):
    """Sets the console font

    A full list of fonts can be found with `ls /usr/share/consolefonts`
    """
    os.system("setfont " + name)


def main():
    """The main function of our program"""

    sound = Sound()
    sound.beep()
    # Choose which function to run
    
    # angle()
    # distance()
    # forward_kinematics()
    # midpoint()
    # position(-64, 142)
    # position_with_jacobian(0,192)



def make_rectange():
    a, b = position(-50, 50)
    a, b = position(-50, 130, origin_t1=a, origin_t2=b)
    a, b = position(-130, 130, origin_t1=a, origin_t2=b)
    a, b = position(-130, 50, origin_t1=a, origin_t2=b)
    a, b = position(-50, 50, origin_t1=a, origin_t2=b)
    a, b = position(2*FIRST_ARM_LENGTH, 0, origin_t1=a, origin_t2=b)


def select_program():
    selection = input("Choose a function to run: ")
    selection_to_function_map = {
        '1': forward_kinematics,
        '2': position,
        '3': midpoint,
        '4': distance,
        '5': angle,
    }
    function = selection_to_function_map.get(selection)
    if function is None:
        print("Invalid selection")
        return
    function()


def forward_kinematics():
    """Given two angles,
    the robot moves to their corresponding joint angles, 
    and returns the (x,y) position of the end effector.
    """
    theta1 = input("Enter theta1: ")
    theta2 = input("Enter theta2: ")
    theta1 = float(theta1)
    theta2 = float(theta2)
    x, y = position_from_angles(theta1, theta2)
    move_arm(theta1, theta2, 10, 10)
    debug_print("The end effector position is ({}, {})".format(x, y))
    return x, y


def position_from_angles(theta1, theta2):
    theta1 = theta1/180*math.pi
    theta2 = theta2/180*math.pi
    x = FIRST_ARM_LENGTH*(math.cos(theta1) + math.cos(theta2))
    y = FIRST_ARM_LENGTH*(math.sin(theta1) + math.sin(theta2))
    return x, y


def position(x, y, origin_t1=0, origin_t2=0):
    """
    Position: Write a program that receives as input a (x,y)
    location inside the robot working space and moves the robot end effector
    to the input location.
    """
    debug_print("x: ", x, " y: ", y)
    time.sleep(1)
    a = math.sqrt(x**2 + y**2)
    theta_offset = math.atan2(-x/a, y/a)/math.pi*180
    if a > 2*FIRST_ARM_LENGTH:
        print("The arm is too long")
        return origin_t1, origin_t2
    theta1 = math.asin(a/(2*FIRST_ARM_LENGTH))/math.pi*180

    theta2 = 180 - theta1 + theta_offset

    theta1 += theta_offset
    debug_print(theta_offset, theta1, theta2)

    delta_theta1 = theta1-origin_t1
    delta_theta2 = theta2-origin_t2
    ratio = abs(delta_theta1/delta_theta2)

    speed = 10
    speed1 = speed
    speed2 = speed

    # if ratio > 1:
    #     speed1 /= ratio
    # else:
    #     speed2 *= ratio

    move_arm(delta_theta1, delta_theta2, speed1, speed2)

    return theta1, theta2


def jacobian_inverse(theta1, theta2):
    """
    Jacobian: Write a program that calculates the inverse Jacobian matrix for inverse kinematics
    """
    
    theta1 = theta1/180*math.pi +0.002
    theta2 = theta2/180*math.pi +0.001
    jacobian = [
    [-1*FIRST_ARM_LENGTH*math.sin(theta1), -1*FIRST_ARM_LENGTH*math.sin(theta2)],
    [FIRST_ARM_LENGTH*math.cos(theta1), FIRST_ARM_LENGTH*math.cos(theta2)]
    ]
    # Calculate the determinant of the jacobian
    det = jacobian[0][0]*jacobian[1][1] - jacobian[0][1]*jacobian[1][0]
    # Calculate the inverse of the jacobian
    jacobian_inverse = [[jacobian[1][1]/det, -1*jacobian[0][1]/det],[-1*jacobian[1][0]/det, jacobian[0][0]/det]]

    return jacobian_inverse

def position_with_jacobian(x, y):
    theta1 = 45
    theta2 = 45
    delta = 0.001
    x_i, y_i = (0,0)
    while (x_i>x+delta or x-delta>x_i) or (y_i>y+delta or y-delta>y_i):
        jacobian_i = jacobian_inverse(theta1, theta2)
        x_i, y_i = position_from_angles(theta1, theta2)
        dx = x-x_i
        dy = y-y_i
        dt1 = jacobian_i[0][0]*dx + jacobian_i[0][1]*dy
        dt2 = jacobian_i[1][0]*dx + jacobian_i[1][1]*dy
        debug_print('pos', x_i, y_i)
        debug_print('theta', dt1, dt2)
        dt1 = dt1*180/math.pi
        dt2 = dt2*180/math.pi
        move_arm(dt1, dt2, 10, 10)
        time.sleep(0.5)
        theta1 += dt1
        theta2 += dt2




def move_arm(delta_theta1, delta_theta2, speed1, speed2):
    arm.left_motor.on_for_degrees(SpeedPercent(speed1),
                                  MOTOR_TO_AXIS_DEGREE*delta_theta1, block=False)
    arm.right_motor.on_for_degrees(SpeedPercent(speed2),
                                   MOTOR_TO_AXIS_DEGREE*delta_theta2, block=False)

    if abs(delta_theta1) > abs(delta_theta2):
        arm.left_motor.wait_until_not_moving()
    else:
        arm.right_motor.wait_until_not_moving()


def midpoint():
    """Finds the midpoint between two points.
    i.e. The user moves the end effector to point 1,
    1
    stores that location then moves the end effector to point 2
    stores the second location and then
    runs the midpoint algorithm
    which calculates and moves the robots end effector into
    the middle location of the two points."""
    # TODO: Test

    point_1_theta1, point_1_theta2 = get_angles()
    debug_print("Angle 1: ", point_1_theta1, point_1_theta2)
    point_2_theta1, point_2_theta2 = get_angles(point_1_theta1, point_1_theta2)
    debug_print("Angle 2: ", point_2_theta1, point_2_theta2)
    x1, y1 = position_from_angles(point_1_theta1, point_1_theta2)
    debug_print("Point 1: ", x1, y1)
    x2, y2 = position_from_angles(point_2_theta1, point_2_theta2)
    debug_print("Point 2: ", x2, y2)
    x_mid = (x1+x2)/2
    y_mid = (y1+y2)/2
    x_mid, y_mid = position(x_mid, y_mid, origin_t1=point_2_theta1, origin_t2=point_2_theta2)
    return x_mid, y_mid


def get_angles(origin_t1=None, origin_t2=None):
    # TODO: Test/Fix this to work for multiple points
    left_motor = arm.left_motor
    right_motor = arm.right_motor
    left_motor.on(SpeedPercent(0))
    right_motor.on(SpeedPercent(0))
    touch_sensor = TouchSensor()
    if origin_t1 is None or origin_t2 is None:
        origin_t1 = left_motor.degrees
        origin_t2 = right_motor.degrees
    curr_left_angle = origin_t1
    curr_right_angle = origin_t2
    theta_1 = 0
    theta_2 = 0
    sound = Sound()
    while True:
        if touch_sensor.is_pressed:
            sound.beep()
            delta_theta_1 = left_motor.degrees-curr_left_angle
            delta_theta_2 = right_motor.degrees-curr_right_angle
            theta_1 = curr_left_angle+delta_theta_1
            theta_2 = curr_right_angle+delta_theta_2
            break
        time.sleep(0.01)
    # Turn off motors
    left_motor.off()
    right_motor.off()
    return theta_1/MOTOR_TO_AXIS_DEGREE, theta_2/MOTOR_TO_AXIS_DEGREE


def distance():
    """Inside the robot working space, a user wants to measure the distance
    between two points.
    The user moves the end effector to the first point,
    clicks a touch sensor for recording the first point,
    then the user locates the end effector over the second location
    and clicks for storing the second point.
    The user gets as output the distance between the two points
    and it is displayed in the EV3 screen (or terminal)."""
    
    first_theta_1, first_theta_2 = get_angles()
    debug_print("first_theta_1: ", first_theta_1, " first_theta_2: ", first_theta_2)
    time.sleep(0.5)
    second_theta_1, second_theta_2 = get_angles()
    debug_print("second_theta_1: ", second_theta_1, " second_theta_2: ", second_theta_2)
    x1, y1 = position_from_angles(first_theta_1, first_theta_2)
    debug_print("first point: ", x1, y1)
    x2, y2 = position_from_angles(second_theta_1, second_theta_2)
    debug_print("second point: ", x2, y2)
    distance = math.sqrt((x2-x1)**2 + (y2-y1)**2)
    debug_print("Distance: ", distance)
    return distance


def angle():
    """Inside the robot working space, a user wants to
    measure the angle between two lines that intersect.
    The user moves the end effector to three points:
    the first point in the line intersection and
    the other two on the different lines.
    The user gets as output the angle between the two lines
    and it is displayed in the EV3 screen (or terminal)."""
    first_theta_1 = 0
    first_theta_2 = 0
    second_theta_1 = 0
    second_theta_2 = 0
    third_theta_1 = 0
    third_theta_2 = 0

    # TODO: store the angles with the points
    first_theta_1, first_theta_2 = get_angles()
    debug_print("first_theta_1: ", first_theta_1, " first_theta_2: ", first_theta_2)
    time.sleep(0.5)
    second_theta_1, second_theta_2 = get_angles()
    debug_print("second_theta_1: ", second_theta_1, " second_theta_2: ", second_theta_2)
    time.sleep(0.5)
    third_theta_1, third_theta_2 = get_angles()
    debug_print("third_theta_1: ", third_theta_1, " third_theta_2: ", third_theta_2)

    x1, y1 = position_from_angles(first_theta_1, first_theta_2)
    debug_print("Intersection Point 1: ", x1, y1)
    x2, y2 = position_from_angles(second_theta_1, second_theta_2)
    debug_print("Point 2: ", x2, y2)
    x3, y3 = position_from_angles(third_theta_1, third_theta_2)
    debug_print("Point 3: ", x3, y3)

    # x1, y1 is the point in the intersection
    # x2, y2 is the point on the first line
    # x3, y3 is the point on the second line
    # Calculate the angle between the two lines

    vector_u = (x2-x1, y2-y1)
    vector_v = (x3-x1, y3-y1)
    u_length = math.sqrt(vector_u[0]**2 + vector_u[1]**2)
    v_length = math.sqrt(vector_v[0]**2 + vector_v[1]**2)
    dot_product = vector_u[0]*vector_v[0] + vector_u[1]*vector_v[1]
    cos_theta = dot_product/(u_length*v_length)
    theta = math.acos(cos_theta)

    debug_print("Angle: ", theta*180/math.pi)
    return angle


if __name__ == "__main__":
    main()
